/*
 * ESP32 LED Control System
 * ------------------------------------------------------------
 * The ESP32 creates its own Wi-Fi Access Point and hosts a small
 * web server. Connect a phone or laptop to the access point,
 * open http://192.168.4.1 and control an LED on GPIO 2.
 *
 * Board    : ESP32 DevKit V1 (Arduino IDE -> "ESP32 Dev Module")
 * Libraries: WiFi.h and WebServer.h (both included with the
 *            ESP32 Arduino core - nothing extra to install)
 * Author   : Selva Kumar SK
 * License  : MIT
 */

#include <WiFi.h>       // Wi-Fi / Access Point support
#include <WebServer.h>  // Simple HTTP server

// ---------------------- Configuration -----------------------
const int LED_PIN = 2;                       // GPIO 2 drives the LED
const char *AP_SSID = "ESP32-LED-Control";   // Wi-Fi network name
const char *AP_PASSWORD = "12345678";        // Wi-Fi password (min. 8 chars)
const uint16_t SERVER_PORT = 80;             // Standard HTTP port

// ------------------------- Globals --------------------------
WebServer server(SERVER_PORT);  // Web server object
bool ledState = false;          // false = OFF, true = ON

// --------------------- Web page (HTML) ----------------------
// Stored in flash. %STATUS% and %STATUS_CLASS% are replaced at runtime.
const char PAGE_TEMPLATE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ESP32 LED Control</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 16px;
      font-family: -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
      background: linear-gradient(135deg, #0f172a, #1e293b);
      color: #e2e8f0;
    }
    .card {
      width: 100%;
      max-width: 420px;
      padding: 32px 24px;
      text-align: center;
      background: #111827;
      border: 1px solid #334155;
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
    }
    h1 { margin: 0 0 4px; font-size: 1.6rem; }
    .subtitle { margin: 0 0 24px; color: #94a3b8; font-size: 0.9rem; }
    .status {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 10px 20px;
      margin-bottom: 28px;
      font-weight: 600;
      border-radius: 999px;
      background: #1f2937;
    }
    .dot { width: 14px; height: 14px; border-radius: 50%; background: #64748b; }
    .status.on  .dot { background: #22c55e; box-shadow: 0 0 10px #22c55e; }
    .status.off .dot { background: #ef4444; }
    .buttons { display: flex; gap: 12px; }
    .btn {
      flex: 1;
      padding: 14px 0;
      font-size: 1rem;
      font-weight: 700;
      text-decoration: none;
      color: #fff;
      border-radius: 10px;
      transition: transform 0.1s, opacity 0.2s;
    }
    .btn:active { transform: scale(0.97); }
    .btn:hover { opacity: 0.9; }
    .btn-on  { background: #16a34a; }
    .btn-off { background: #dc2626; }
    footer { margin-top: 24px; font-size: 0.75rem; color: #64748b; }
    @media (max-width: 380px) { .buttons { flex-direction: column; } }
  </style>
</head>
<body>
  <main class="card">
    <h1>ESP32 LED Control System</h1>
    <p class="subtitle">IoT &amp; Embedded Systems Project</p>

    <div class="status %STATUS_CLASS%">
      <span class="dot"></span>
      <span>LED Status: %STATUS%</span>
    </div>

    <div class="buttons">
      <a class="btn btn-on" href="/on">TURN ON</a>
      <a class="btn btn-off" href="/off">TURN OFF</a>
    </div>

    <footer>ESP32 Access Point &bull; 192.168.4.1 &bull; GPIO 2</footer>
  </main>
</body>
</html>
)rawliteral";

// ------------------------ Helpers ---------------------------

// Apply the LED state to the GPIO pin.
void applyLed(bool on) {
  ledState = on;
  digitalWrite(LED_PIN, ledState ? HIGH : LOW);
  Serial.println(ledState ? "[LED] Turned ON" : "[LED] Turned OFF");
}

// Build the final HTML page by inserting the current LED status.
String buildPage() {
  String page = FPSTR(PAGE_TEMPLATE);
  page.replace("%STATUS_CLASS%", ledState ? "on" : "off");
  page.replace("%STATUS%", ledState ? "ON" : "OFF");
  return page;
}

// ---------------------- Route handlers ----------------------

// GET /  -> show the control page
void handleRoot() {
  Serial.println("[HTTP] GET /");
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "text/html", buildPage());
}

// GET /on  -> switch LED on, then redirect back to the page
void handleOn() {
  Serial.println("[HTTP] GET /on");
  applyLed(true);
  server.sendHeader("Location", "/");
  server.send(303);  // 303 See Other: avoids re-triggering on refresh
}

// GET /off -> switch LED off, then redirect back to the page
void handleOff() {
  Serial.println("[HTTP] GET /off");
  applyLed(false);
  server.sendHeader("Location", "/");
  server.send(303);
}

// Any unknown URL -> 404
void handleNotFound() {
  Serial.print("[HTTP] 404 Not Found: ");
  Serial.println(server.uri());
  server.send(404, "text/plain", "404 - Page not found");
}

// -------------------------- Setup ---------------------------
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println();
  Serial.println("=== ESP32 LED Control System ===");

  // Configure the LED pin and make sure the LED starts OFF
  pinMode(LED_PIN, OUTPUT);
  applyLed(false);

  // Start the ESP32 as a Wi-Fi Access Point
  WiFi.mode(WIFI_AP);
  bool apStarted = WiFi.softAP(AP_SSID, AP_PASSWORD);
  if (apStarted) {
    Serial.println("[WiFi] Access Point started");
    Serial.print("[WiFi] SSID     : ");
    Serial.println(AP_SSID);
    Serial.print("[WiFi] Password : ");
    Serial.println(AP_PASSWORD);
    Serial.print("[WiFi] IP       : ");
    Serial.println(WiFi.softAPIP());  // Default is 192.168.4.1
  } else {
    Serial.println("[WiFi] ERROR: Access Point failed to start");
  }

  // Register routes and start the web server
  server.on("/", HTTP_GET, handleRoot);
  server.on("/on", HTTP_GET, handleOn);
  server.on("/off", HTTP_GET, handleOff);
  server.onNotFound(handleNotFound);
  server.begin();
  Serial.println("[HTTP] Web server started on port 80");
  Serial.println("Open http://192.168.4.1 in your browser");
}

// --------------------------- Loop ---------------------------
void loop() {
  server.handleClient();  // Process incoming HTTP requests
}
