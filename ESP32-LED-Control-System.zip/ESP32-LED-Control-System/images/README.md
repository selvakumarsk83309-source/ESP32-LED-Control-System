# Project Images

This folder is for **your own photos and screenshots** of the real project. This repository does not include any hardware photos. Add your own once you have built the circuit.

## Suggested filenames

```
images/
├── hardware_setup.jpg
├── circuit_connection.jpg
├── serial_monitor.jpg
├── web_interface.jpg
└── led_on.jpg
```

| File | What to capture |
|------|-----------------|
| `hardware_setup.jpg` | Full view of the ESP32, breadboard, LED and USB cable |
| `circuit_connection.jpg` | Close-up of the wiring (GPIO 2, resistor, LED, GND) |
| `serial_monitor.jpg` | Screenshot of the Serial Monitor startup messages |
| `web_interface.jpg` | Screenshot of the web page on your phone or laptop |
| `led_on.jpg` | Photo of the LED lit after pressing TURN ON |

## Tips

- Use clear, well-lit photos and keep files reasonably small (under 2 MB each).
- Only upload images you took yourself.

## Show them in the main README (optional)

After adding the images, you can display them in the main `README.md`, for example:

```markdown
![Hardware Setup](images/hardware_setup.jpg)
```

Add these lines only for image files that actually exist, otherwise GitHub will show a broken image.
