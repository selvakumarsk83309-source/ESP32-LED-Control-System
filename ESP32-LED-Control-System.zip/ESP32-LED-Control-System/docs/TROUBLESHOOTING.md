# Troubleshooting

Find your problem below and try the fixes in order.

## ESP32 not detected

- Use a different USB cable. Many cables are charge-only and carry no data.
- Try another USB port, and connect directly to the computer (not through a hub).
- Install the CP210x or CH340 USB driver for your board.
- Check that the board's power LED is on.

## COM port missing

- Reconnect the USB cable and check **Tools → Port** again.
- Install the correct USB-to-serial driver, then restart the Arduino IDE.
- On Windows, check **Device Manager → Ports (COM & LPT)** and look for an unknown device.
- On Linux, add your user to the serial group (for example `sudo usermod -a -G dialout $USER`) and log in again.
- Close other programs using the port (other Serial Monitors, terminal programs).

## Upload failed

- Confirm **Board = ESP32 Dev Module** and the correct port.
- If you see `Connecting........`, hold the **BOOT** button until uploading starts.
- Try a different USB cable or port.
- Close the Serial Monitor before uploading.
- Lower the **Upload Speed** in the Tools menu (for example to 115200).
- Unplug anything connected to the ESP32 pins during upload if the problem continues.

## LED not turning ON

- Check the LED direction: the long leg (anode) must be on the resistor side.
- Check that the ESP32 GPIO 2 wire goes to the resistor and the cathode goes to GND.
- Check that all parts are fully inserted in the breadboard and in different rows.
- Upload `examples/basic_led_test/basic_led_test.ino` to test the hardware.
- Try another LED and check the resistor value.

## LED always ON

- Check that the LED and resistor are not connected to 3.3 V or 5 V instead of GPIO 2.
- Check that the sketch uploaded is `LED_Control_System.ino` and that you pressed **TURN OFF**.
- Look for a wire touching the wrong pin or row.
- Note that GPIO 2 also drives the on-board LED on many boards. Only your external LED matters for this test.

## Wi-Fi network not visible

- Check the Serial Monitor for `[WiFi] Access Point started`.
- Press the **EN (Reset)** button and wait about 10 seconds.
- Move the phone or laptop closer to the ESP32.
- Refresh the Wi-Fi list, or turn Wi-Fi off and on.
- Use a device that supports 2.4 GHz Wi-Fi (the ESP32 does not use 5 GHz).
- Make sure the board is powered adequately (try another USB port or cable).

## 192.168.4.1 not opening

- Confirm you are connected to **ESP32-LED-Control** (not your home Wi-Fi).
- Type the address exactly: `http://192.168.4.1`.
- Turn off mobile data on a phone. Some phones send traffic through mobile data when the Wi-Fi has no internet.
- Turn off any VPN or private DNS/proxy.
- Check the IP address shown in the Serial Monitor.

## Browser page not loading

- Use `http://`, not `https://`.
- Stop the browser from auto-upgrading to HTTPS, or try another browser or a private window.
- Refresh the page or clear the browser cache.
- Disconnect and reconnect to the ESP32 Wi-Fi.
- Reset the ESP32 and try again.

## Wrong LED polarity

- If the LED does not light, remove it and reinsert it the other way around.
- A reverse-connected LED is normally not damaged by this low voltage, but always check the wiring before powering on.
- Long leg = anode (+) toward the resistor. Short leg = cathode (−) toward GND.

## GPIO issue

- Confirm that the sketch uses `const int LED_PIN = 2;` and that your wire is on the pin labelled **GPIO2** / **D2**.
- Pin labels can differ between board makers. Compare with your board's pinout.
- GPIO 2 is a boot-related pin on the ESP32. If uploading fails with something connected, disconnect the LED wire temporarily during upload.
- To use another GPIO, change `LED_PIN` in the sketch and move the wire.

## Serial Monitor shows garbage characters

- Set the baud rate to **115200** in the Serial Monitor.
- Press the **EN (Reset)** button after changing the baud rate.
- Check that the sketch contains `Serial.begin(115200);`.
- Try another USB cable.

## Still stuck?

Open an issue in the GitHub repository and include your board model, Arduino IDE version, ESP32 package version and the exact error message.
