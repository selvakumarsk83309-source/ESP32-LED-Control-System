# ESP32 LED Control System - Project Documentation

**Author:** Selva Kumar SK
**Programme:** B.E. Electronics and Communication Engineering, VSB Engineering College
**Internship:** IoT & Embedded Systems Internship

---

## 1. Abstract

This project presents an ESP32-based LED control system in which the microcontroller creates its own Wi-Fi Access Point and hosts a web server. A user connects a phone or laptop to the ESP32 network, opens `http://192.168.4.1` in a browser and switches an external LED ON or OFF using buttons on a responsive web page. The page also shows the current LED status. The system is built with an ESP32 DevKit V1, an LED, a 220Ω resistor and a breadboard, and is programmed in Embedded C/C++ using the Arduino IDE. It demonstrates GPIO control, Wi-Fi Access Point mode, HTTP request handling and embedded web design.

## 2. Introduction

The Internet of Things (IoT) connects physical devices to users through networks. The ESP32 is a low-cost microcontroller with built-in Wi-Fi and Bluetooth, which makes it suitable for learning IoT. Controlling an LED is a simple first step that introduces the core idea of IoT: a user sends a command over a network and a physical output responds.

## 3. Problem Statement

Beginners often learn GPIO control and networking separately. There is a need for a simple project that combines both, so that a physical device can be controlled wirelessly without depending on an existing router or internet connection.

## 4. Objectives

- Interface an external LED with the ESP32 using a current-limiting resistor.
- Configure the ESP32 as a Wi-Fi Access Point.
- Host a web server on the ESP32 to receive control commands.
- Design a responsive web interface embedded in the firmware.
- Display the current LED status to the user.
- Document the project so that others can reproduce it.

## 5. Proposed Solution

The ESP32 operates in Access Point mode with the SSID `ESP32-LED-Control` and password `12345678`. It runs a web server on port 80 with three routes: `/`, `/on` and `/off`. The HTML and CSS are stored inside the sketch, so no external files or internet resources are required. GPIO 2 drives the LED through a 220Ω resistor.

## 6. System Architecture

```
Phone / Laptop
      |
      |  Wi-Fi
      v
ESP32 Access Point
      |
      v
ESP32 Web Server (port 80)
      |
      v
GPIO 2
      |
    220Ω
      |
     LED
      |
     GND
```

| Layer | Component |
|-------|-----------|
| User interface | Web browser on phone or laptop |
| Network | Wi-Fi Access Point created by the ESP32 (192.168.4.1) |
| Application | HTTP server with routes `/`, `/on`, `/off` |
| Hardware interface | GPIO 2 configured as digital output |
| Output device | External LED with 220Ω resistor |

## 7. Hardware Components

| Component | Quantity | Purpose |
|-----------|:--------:|---------|
| ESP32 DevKit V1 | 1 | Microcontroller, Wi-Fi, web server |
| LED | 1 | Output indicator |
| 220Ω resistor | 1 | Limits LED current |
| Breadboard | 1 | Solderless circuit assembly |
| Jumper wires | 3 | Electrical connections |
| USB cable | 1 | Power and programming |

## 8. Software Requirements

- Arduino IDE
- ESP32 board package by Espressif Systems
- Libraries `WiFi.h` and `WebServer.h` (included with the ESP32 package)
- A web browser on a Wi-Fi enabled phone or laptop

## 9. Circuit Description

GPIO 2 of the ESP32 connects to one end of a 220Ω resistor. The other end of the resistor connects to the LED anode (+). The LED cathode (−) connects to the ESP32 GND pin.

When GPIO 2 is HIGH (about 3.3 V), current flows through the resistor and LED to GND and the LED lights. When GPIO 2 is LOW (0 V), no current flows and the LED is off.

Approximate LED current, assuming a typical red LED forward voltage of about 2 V:

```
I = (3.3 V - 2.0 V) / 220 Ω ≈ 5.9 mA
```

This is within the safe range for an ESP32 GPIO pin and a standard LED. The actual value depends on the LED used.

See [`circuit/circuit_diagram.png`](../circuit/circuit_diagram.png).

## 10. Working Principle

1. The ESP32 starts, sets GPIO 2 as an output and turns the LED OFF.
2. It starts the Wi-Fi Access Point and the web server.
3. The user joins the ESP32 network and opens `http://192.168.4.1`.
4. The ESP32 responds with the HTML control page showing the LED status.
5. Pressing **TURN ON** sends `GET /on`. The ESP32 sets GPIO 2 HIGH and redirects to `/`.
6. Pressing **TURN OFF** sends `GET /off`. The ESP32 sets GPIO 2 LOW and redirects to `/`.
7. The page reloads and shows the updated status.

## 11. Software Flow

```
Start
  |
Initialise Serial (115200)
  |
Configure GPIO 2 as OUTPUT, LED = OFF
  |
Start Wi-Fi Access Point
  |
Register routes: /, /on, /off
  |
Start web server (port 80)
  |
  +--> Loop: handle client requests
          |
          +-- "/"     -> send HTML page (HTTP 200)
          +-- "/on"   -> LED ON,  redirect to "/" (HTTP 303)
          +-- "/off"  -> LED OFF, redirect to "/" (HTTP 303)
          +-- other   -> HTTP 404
```

## 12. Web Interface

The interface is written in HTML and CSS and stored in the sketch. It contains:

- Project title
- LED status indicator (green when ON, red when OFF)
- **TURN ON** and **TURN OFF** buttons
- A responsive layout that adapts to phone and laptop screens (flexible width, viewport meta tag and a media query)

No JavaScript frameworks, CDN links or external resources are used.

## 13. Testing

The following test procedure is recommended. Record your own observations and add photos to the `images/` folder.

| No. | Test | Expected result |
|:---:|------|-----------------|
| 1 | Upload `basic_led_test.ino` | LED blinks (1 s ON, 1 s OFF) |
| 2 | Upload `LED_Control_System.ino`, open Serial Monitor | Startup messages appear, IP is 192.168.4.1 |
| 3 | Search for Wi-Fi networks | `ESP32-LED-Control` is visible |
| 4 | Connect with password `12345678` | Connection succeeds |
| 5 | Open `http://192.168.4.1` | Control page loads |
| 6 | Press TURN ON | LED lights, status shows ON |
| 7 | Press TURN OFF | LED turns off, status shows OFF |
| 8 | Refresh the page | Status remains correct |
| 9 | Open an unknown URL such as `/test` | "404 - Page not found" |

## 14. Results

The design provides wireless control of an LED through a web page hosted on the ESP32, with status feedback in the browser and messages in the Serial Monitor. Actual measurements and observations should be recorded by the person who builds the hardware; this repository does not include any recorded test results.

## 15. Advantages

- No router or internet connection required
- Low cost and simple hardware
- Works from any device with Wi-Fi and a browser
- No app installation needed
- No external libraries or web resources
- Beginner friendly and easy to extend

## 16. Limitations

- Controls only one LED
- Wi-Fi range is limited to the ESP32 Access Point range
- The phone or laptop must disconnect from its normal Wi-Fi to join the ESP32 network
- No authentication on the web page (anyone who knows the Wi-Fi password can control the LED)
- Uses a simple, fixed Wi-Fi password and unencrypted HTTP
- LED state is not stored and resets to OFF after a restart
- Page reloads after each button press instead of updating in place

## 17. Future Scope

The following are possible extensions and are **not implemented** in this version:

- Multiple LED or relay control
- PWM brightness control
- Sensor integration
- MQTT communication
- Cloud IoT dashboard
- Login and authentication
- Station (router-connected) Wi-Fi mode

## 18. Conclusion

The project demonstrates the basic IoT workflow of a user command travelling over Wi-Fi to a microcontroller that controls a physical output. It covers GPIO interfacing, Access Point configuration, HTTP request handling and responsive web design, and gives a base for larger projects.
