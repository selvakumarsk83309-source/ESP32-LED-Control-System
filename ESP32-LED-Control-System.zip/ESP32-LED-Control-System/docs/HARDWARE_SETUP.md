# Hardware Setup

## Components

| Component | Quantity |
|-----------|:--------:|
| ESP32 DevKit V1 | 1 |
| LED (any color) | 1 |
| 220Ω resistor | 1 |
| Breadboard | 1 |
| Jumper wires | 3 |
| USB cable (data-capable) | 1 |

## ESP32 Pin Identification

- Pin labels are printed on the board next to each header pin. Look for **D2** or **GPIO2** (labelled `D2` on many DevKit V1 boards) and **GND**.
- The ESP32 DevKit V1 has more than one GND pin. Any of them works.
- Pin layouts vary slightly between manufacturers. **Always use the labels printed on your board**, not only a picture.
- Many DevKit V1 boards have an on-board LED connected to GPIO 2. It may blink together with your external LED. This is normal.

## LED Polarity

An LED only works in one direction.

| Terminal | How to identify |
|----------|-----------------|
| Anode (+) | Longer leg |
| Cathode (−) | Shorter leg, flat edge on the LED body |

## Why the Resistor Is Needed

An LED has almost no resistance once it conducts. Without a resistor, too much current would flow and could damage the LED and the ESP32 pin. The 220Ω resistor limits the current to a few milliamps (about 6 mA for a typical red LED). Resistor orientation does not matter.

## Connection Table

| From | To |
|------|----|
| ESP32 GPIO 2 | One leg of the 220Ω resistor |
| Other leg of the 220Ω resistor | LED anode (+, long leg) |
| LED cathode (−, short leg) | ESP32 GND |

## Breadboard Setup

1. Unplug the USB cable before wiring.
2. Place the ESP32 on the breadboard, or keep it beside it and use jumper wires to its header pins.
3. Insert the LED so the anode and cathode are in **different** breadboard rows (each row of 5 holes is connected).
4. Insert the resistor with one leg in the **same row as the LED anode** and the other leg in a **different, empty row**.
5. Jumper wire 1: ESP32 **GPIO 2** to the free resistor row.
6. Jumper wire 2: LED **cathode** row to the ESP32 **GND** pin (or the breadboard GND rail if the ESP32 GND is connected to it).
7. Double-check against the [circuit diagram](../circuit/circuit_diagram.png).

## USB Connection

1. Connect the USB cable to the ESP32 micro-USB port and to your computer.
2. The power LED on the board should light.
3. Use a **data** cable. Charge-only cables will not let the computer detect the board.

## Common Wiring Mistakes

- LED connected backwards (anode and cathode swapped)
- Resistor and LED legs in the same breadboard row (short circuit or bypassed part)
- Wire connected to the wrong pin (for example GPIO 4 instead of GPIO 2)
- Missing GND connection
- Loose jumper wires or components not fully inserted
- Using a charge-only USB cable
- Connecting the LED directly to a GPIO pin without a resistor

## Safety Precautions

- Always disconnect USB power before changing the wiring.
- Never connect an LED directly to a GPIO pin without a resistor.
- Do not connect any pin to 5 V or a higher voltage source. ESP32 GPIO pins are 3.3 V logic.
- Do not short 3.3 V or 5 V pins to GND.
- Handle the board by its edges and avoid touching components while powered.
- Use a proper USB cable and port.
