# Software Setup

A beginner-friendly guide to programming the ESP32 with the Arduino IDE.

## 1. Install the Arduino IDE

1. Go to <https://www.arduino.cc/en/software>.
2. Download the Arduino IDE (version 2.x recommended) for your operating system.
3. Install it and open it.

## 2. Install the ESP32 Board Package

1. Open **File → Preferences**.
2. In **Additional boards manager URLs**, paste:
   ```
   https://espressif.github.io/arduino-esp32/package_esp32_index.json
   ```
3. Click **OK**.
4. Open **Tools → Board → Boards Manager** (or click the board icon on the left).
5. Search for **esp32**.
6. Install **esp32 by Espressif Systems** and wait until it finishes.

## 3. Install the USB Driver (if needed)

If your computer does not show a port when the ESP32 is connected, install the driver for the USB chip on your board (usually **CP210x** or **CH340**). Look at the small chip near the USB connector or check your board's documentation.

## 4. Select the Board

Go to **Tools → Board → ESP32 Arduino → ESP32 Dev Module**.

## 5. Select the COM Port

1. Connect the ESP32 with a USB data cable.
2. Go to **Tools → Port**.
3. Select the new port (for example `COM3` on Windows, `/dev/ttyUSB0` on Linux, `/dev/cu.usbserial-...` on macOS).

If no port appears, see [Troubleshooting](TROUBLESHOOTING.md).

## 6. Open the Sketch

1. Open **File → Open**.
2. Choose `src/LED_Control_System.ino`.
3. If the IDE asks to move the sketch into a folder of the same name, click **OK**.

## 7. Upload

1. Click **Verify** (✓) to compile.
2. Click **Upload** (→).
3. If the IDE shows `Connecting........`, press and hold the **BOOT** button on the ESP32 until uploading starts, then release it.
4. Wait for **Done uploading**.

Tip: upload `examples/basic_led_test/basic_led_test.ino` first to check that your LED wiring works.

## 8. Open the Serial Monitor

1. Open **Tools → Serial Monitor**.
2. Set the baud rate to **115200**.
3. Press the **EN (Reset)** button on the ESP32 to see the startup messages.

Expected messages:

```
=== ESP32 LED Control System ===
[LED] Turned OFF
[WiFi] Access Point started
[WiFi] SSID     : ESP32-LED-Control
[WiFi] Password : 12345678
[WiFi] IP       : 192.168.4.1
[HTTP] Web server started on port 80
Open http://192.168.4.1 in your browser
```

## 9. Connect to the Wi-Fi Network

1. On your phone or laptop open Wi-Fi settings.
2. Select **ESP32-LED-Control**.
3. Enter the password **12345678**.
4. If a message says there is no internet, stay connected.

## 10. Test in the Browser

1. Open a browser.
2. Type **http://192.168.4.1** in the address bar (use `http`, not `https`).
3. Press **TURN ON** and **TURN OFF** and watch the LED and the status text.
