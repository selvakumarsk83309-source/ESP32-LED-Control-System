/*
 * Basic LED Test
 * ------------------------------------------------------------
 * Use this sketch to verify your LED wiring BEFORE testing Wi-Fi.
 * The LED on GPIO 2 blinks: 1 second ON, 1 second OFF, forever.
 *
 * Board : ESP32 DevKit V1 (Arduino IDE -> "ESP32 Dev Module")
 */

// GPIO number the LED circuit is connected to
const int LED_PIN = 2;

void setup() {
  // Make GPIO 2 an output so the ESP32 can drive the LED
  pinMode(LED_PIN, OUTPUT);

  // Start serial communication so we can print messages (115200 baud)
  Serial.begin(115200);
  Serial.println("Basic LED test started on GPIO 2");
}

void loop() {
  digitalWrite(LED_PIN, HIGH);  // Set pin HIGH (3.3 V) -> LED ON
  Serial.println("LED ON");
  delay(1000);                  // Wait 1000 ms (1 second)

  digitalWrite(LED_PIN, LOW);   // Set pin LOW (0 V) -> LED OFF
  Serial.println("LED OFF");
  delay(1000);                  // Wait 1 second, then the loop repeats
}
